import hashlib

def verify_token(token):
    digest = hashlib.sha256(token.encode()).hexdigest()
    return {"user_id": digest[:8]}
