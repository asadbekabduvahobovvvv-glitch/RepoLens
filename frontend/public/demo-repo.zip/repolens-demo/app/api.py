from services.auth import authenticate
from services.billing import charge_customer
from config.settings import API_VERSION

def start_server():
    return API_VERSION

def login_route(token):
    return authenticate(token)

def checkout_route(user_id, amount):
    return charge_customer(user_id, amount)
