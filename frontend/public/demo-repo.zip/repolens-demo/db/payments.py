def create_payment(user, amount):
    return {"user": user["id"], "amount": amount}
