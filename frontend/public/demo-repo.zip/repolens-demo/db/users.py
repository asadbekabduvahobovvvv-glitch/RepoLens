USERS = {}

def get_user(user_id):
    return USERS.get(user_id, {"id": user_id})
