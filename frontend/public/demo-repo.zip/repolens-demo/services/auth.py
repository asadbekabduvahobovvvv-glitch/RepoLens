from core.crypto import verify_token
from db.users import get_user

class AuthService:
    pass

def authenticate(token):
    payload = verify_token(token)
    return get_user(payload.get("user_id"))
