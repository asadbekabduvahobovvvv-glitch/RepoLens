from db.payments import create_payment
from db.users import get_user

def charge_customer(user_id, amount):
    user = get_user(user_id)
    return create_payment(user, amount)
