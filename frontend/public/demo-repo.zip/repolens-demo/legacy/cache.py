from legacy.session import load_session

def warm_cache(session_id):
    return load_session(session_id)
