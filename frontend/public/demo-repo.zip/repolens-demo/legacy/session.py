from legacy.cache import warm_cache

def load_session(session_id):
    return {"session_id": session_id}
